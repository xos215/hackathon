const $ = (s) => document.querySelector(s);
const $$ = (s) => document.querySelectorAll(s);

function escapeHtml(value) {
  return String(value).replace(/[&<>"']/g, c => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"
  }[c]));
}

function badge(status) {
  const clean = String(status).toLowerCase();
  const cls = clean === "present" ? "badge-present" : clean === "absent" ? "badge-absent" : "badge-pending";
  return `<span class="badge ${cls}">${escapeHtml(status)}</span>`;
}

function tableHtml(rows) {
  if (!rows.length) return `<p class="story">No records found yet.</p>`;
  return `
  <div class="table-wrap">
    <table class="data-table">
      <thead><tr><th>NAME</th><th>CATEGORY</th><th>STATUS</th><th>DATE</th><th></th></tr></thead>
      <tbody>
        ${rows.map(r => `
          <tr>
            <td><strong>${escapeHtml(r.name)}</strong></td>
            <td>${escapeHtml(r.category)}</td>
            <td>${badge(r.status)}</td>
            <td>${escapeHtml(r.record_date)}</td>
            <td><button class="delete-btn" onclick="deleteRecord(${r.id})">Delete</button></td>
          </tr>`).join("")}
      </tbody>
    </table>
  </div>`;
}

async function loadRecords(search = "") {
  const res = await fetch(`/api/records?search=${encodeURIComponent(search)}`);
  const rows = await res.json();
  $("#allTable").innerHTML = tableHtml(rows);
  $("#recentTable").innerHTML = tableHtml(rows.slice(0, 5));
}

async function loadStats() {
  const res = await fetch("/api/stats");
  const s = await res.json();
  $("#totalStat").textContent = s.total;
  $("#presentStat").textContent = s.present;
  $("#absentStat").textContent = s.absent;
  $("#rateStat").textContent = `${s.rate}%`;
  $("#aPresent").textContent = s.present;
  $("#aAbsent").textContent = s.absent;
  $("#aPending").textContent = s.pending;

  const max = Math.max(...s.days.map(d => d.total), 1);
  $("#chart").innerHTML = s.days.length
    ? s.days.map(d => `
      <div class="bar-wrap">
        <div class="bar-value">${d.total}</div>
        <div class="bar" style="height:${Math.max(8, (d.total/max)*78)}%"></div>
        <div class="bar-label">${d.record_date.slice(5)}</div>
      </div>`).join("")
    : `<p class="story">Add records to generate activity.</p>`;
}

async function refresh() {
  await Promise.all([loadRecords(), loadStats()]);
}

function showToast(msg) {
  const t = $("#toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 1800);
}

function openModal() { $("#modal").classList.remove("hidden"); }
function closeModal() { $("#modal").classList.add("hidden"); }

async function deleteRecord(id) {
  await fetch(`/api/records/${id}`, {method:"DELETE"});
  await refresh();
  showToast("Record deleted");
}

$("#openModal").addEventListener("click", openModal);
$("#quickAdd").addEventListener("click", openModal);
$("#closeModal").addEventListener("click", closeModal);

$("#modal").addEventListener("click", e => {
  if (e.target === $("#modal")) closeModal();
});

$("#recordForm").addEventListener("submit", async e => {
  e.preventDefault();
  const form = new FormData(e.target);
  const payload = Object.fromEntries(form.entries());

  const res = await fetch("/api/records", {
    method:"POST",
    headers:{"Content-Type":"application/json"},
    body:JSON.stringify(payload)
  });

  if (!res.ok) {
    const err = await res.json();
    showToast(err.error || "Could not save");
    return;
  }

  e.target.reset();
  closeModal();
  await refresh();
  showToast("Record added");
});

$("#searchInput").addEventListener("input", e => loadRecords(e.target.value));

$$(".nav-item").forEach(btn => {
  btn.addEventListener("click", () => switchSection(btn.dataset.section));
});

$$("[data-scroll]").forEach(btn => {
  btn.addEventListener("click", () => switchSection(btn.dataset.scroll));
});

function switchSection(id) {
  $$(".section").forEach(s => s.classList.remove("active-section"));
  $("#" + id).classList.add("active-section");
  $$(".nav-item").forEach(n => n.classList.toggle("active", n.dataset.section === id));
}

$("#modal").classList.add("hidden");
refresh();

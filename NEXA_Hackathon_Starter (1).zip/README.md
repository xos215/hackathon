# NEXA Smart Tracker

A hackathon-ready starter application using:

- Frontend: HTML + CSS + JavaScript
- Backend: Python + Flask
- Database: SQLite

## Run it

1. Install Python 3.
2. Open a terminal inside this folder.
3. Create a virtual environment (optional but recommended):

   Windows:
   python -m venv venv
   venv\Scripts\activate

4. Install Flask:

   pip install -r requirements.txt

5. Start the server:

   python app.py

6. Open the address shown in the terminal, usually:
   http://127.0.0.1:5000

## What each file does

- `app.py` = backend + database API
- `templates/index.html` = page structure
- `static/style.css` = appearance
- `static/script.js` = browser logic + fetch calls
- `database.db` = created automatically on first run

## How to adapt it tomorrow

### Attendance system
Change:
- Category -> Subject
- Status -> Present / Absent / Late
- Dashboard card labels -> Students / Present / Absent / Attendance %
- Rename the app and text in `index.html`
- Update demo rows in `app.py`

### Library system
Change:
- Category -> Author / Genre
- Status -> Available / Borrowed / Overdue
- Dashboard labels -> Total Books / Borrowed / Available / Overdue

### Task manager
Change:
- Category -> Priority / Team
- Status -> Done / Open / Pending
- Dashboard labels -> Total Tasks / Done / Open / Completion %

## The important request flow

HTML form
  -> JavaScript fetch()
  -> Flask route in app.py
  -> SQLite
  -> JSON response
  -> JavaScript refreshes the page

## Jury demo script

1. Show the dashboard.
2. Add a new record live.
3. Point out that the number and activity chart update.
4. Search for a record.
5. Delete a record.
6. Explain: "The frontend communicates with a Flask API, while SQLite provides persistent relational storage."

## Fastest customization

Search in `templates/index.html` for:
- NEXA
- TOTAL RECORDS
- PRESENT / DONE
- ABSENT / OPEN
- Category

Those are the easiest visible pieces to rename.

from flask import Flask, render_template, request, jsonify
import sqlite3
from datetime import datetime, date
from pathlib import Path

app = Flask(__name__)
DB_PATH = Path(__file__).with_name("database.db")


def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn


def init_db():
    conn = get_db()
    conn.execute("""
        CREATE TABLE IF NOT EXISTS records (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT NOT NULL,
            category TEXT NOT NULL,
            status TEXT NOT NULL,
            record_date TEXT NOT NULL
        )
    """)

    count = conn.execute("SELECT COUNT(*) AS c FROM records").fetchone()["c"]
    if count == 0:
        demo = [
            ("Rahul", "Mathematics", "Present", "2026-09-29"),
            ("Priya", "English", "Present", "2026-09-29"),
            ("Arjun", "Hindi", "Absent", "2026-09-29"),
            ("Ananya", "Mathematics", "Present", "2026-09-28"),
            ("Vikram", "English", "Present", "2026-09-28"),
            ("Meera", "Hindi", "Pending", "2026-09-27"),
        ]
        conn.executemany(
            "INSERT INTO records (name, category, status, record_date) VALUES (?, ?, ?, ?)",
            demo
        )
    conn.commit()
    conn.close()


@app.route("/")
def index():
    return render_template("index.html")


@app.get("/api/records")
def records():
    search = request.args.get("search", "").strip()
    conn = get_db()
    if search:
        rows = conn.execute("""
            SELECT * FROM records
            WHERE name LIKE ? OR category LIKE ? OR status LIKE ?
            ORDER BY id DESC
        """, (f"%{search}%", f"%{search}%", f"%{search}%")).fetchall()
    else:
        rows = conn.execute("SELECT * FROM records ORDER BY id DESC").fetchall()
    conn.close()
    return jsonify([dict(r) for r in rows])


@app.get("/api/stats")
def stats():
    conn = get_db()
    total = conn.execute("SELECT COUNT(*) c FROM records").fetchone()["c"]
    present = conn.execute(
        "SELECT COUNT(*) c FROM records WHERE LOWER(status) = 'present'"
    ).fetchone()["c"]
    absent = conn.execute(
        "SELECT COUNT(*) c FROM records WHERE LOWER(status) = 'absent'"
    ).fetchone()["c"]
    pending = conn.execute(
        "SELECT COUNT(*) c FROM records WHERE LOWER(status) = 'pending'"
    ).fetchone()["c"]

    by_day = conn.execute("""
        SELECT record_date, COUNT(*) AS total
        FROM records
        GROUP BY record_date
        ORDER BY record_date DESC
        LIMIT 7
    """).fetchall()

    conn.close()

    rate = round((present / total) * 100) if total else 0
    return jsonify({
        "total": total,
        "present": present,
        "absent": absent,
        "pending": pending,
        "rate": rate,
        "days": [dict(r) for r in reversed(by_day)]
    })


@app.post("/api/records")
def add_record():
    data = request.get_json(silent=True) or {}
    name = str(data.get("name", "")).strip()
    category = str(data.get("category", "")).strip()
    status = str(data.get("status", "")).strip()
    record_date = str(data.get("record_date", "")).strip() or date.today().isoformat()

    if not name or not category or not status:
        return jsonify({"error": "Name, category and status are required."}), 400

    conn = get_db()
    cur = conn.execute(
        "INSERT INTO records (name, category, status, record_date) VALUES (?, ?, ?, ?)",
        (name, category, status, record_date)
    )
    conn.commit()
    row = conn.execute("SELECT * FROM records WHERE id = ?", (cur.lastrowid,)).fetchone()
    conn.close()
    return jsonify(dict(row)), 201


@app.delete("/api/records/<int:record_id>")
def delete_record(record_id):
    conn = get_db()
    conn.execute("DELETE FROM records WHERE id = ?", (record_id,))
    conn.commit()
    conn.close()
    return jsonify({"ok": True})


if __name__ == "__main__":
    init_db()
    app.run(debug=True)
